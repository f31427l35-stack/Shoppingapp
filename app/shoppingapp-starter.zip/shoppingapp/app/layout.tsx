import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata={title:"ShopZone - Online Shopping",description:"Shop phones, electronics, fashion, appliances and more at great prices."};
export default function RootLayout({children}:{readonly children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
